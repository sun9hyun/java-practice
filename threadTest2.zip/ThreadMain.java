package thread.threadTest2;

public class ThreadMain {

}
